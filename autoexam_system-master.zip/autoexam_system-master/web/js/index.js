/**
 * Created by Yc on 2015/9/17.
 */
$(document).ready(function () {
    $('.carousel').carousel()

})