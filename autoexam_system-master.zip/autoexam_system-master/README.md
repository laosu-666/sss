# 在线考试系统

**线上地址是好久之前搭建的，你可以clone代码至本地运行，部分界面截图[在这](https://imcuttle.github.io/talk-about-websocket)可以找到**

~地址: http://moyuyc.xyz/autoexam~

