package test;

import java.util.Date;

public class TestTime {
public static void main(String[] args) {
	Date d=new Date();
}
}
