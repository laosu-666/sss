 window.onload=function(){
   	var del=document.getElementsByTagName('button')[0];
   	var ins=document.getElementsByTagName('button')[1];
   	function delTeacher(){
   		
   	}
   	
   }