﻿//全选

//button按钮点击事件
   window.onload=function(){
   	var del=document.getElementsByTagName('button')[0];
   	var ins=document.getElementsByTagName('button')[1];
   	function delTeacher(){
   		
   	}
   	
   }
